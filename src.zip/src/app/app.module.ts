import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { StandbyComponent } from './standby/standby.component';
import { ActiveFromOfficeComponent } from './active-from-office/active-from-office.component';
import { PointAComponent } from './point-a/point-a.component';
import { PointBComponent } from './point-b/point-b.component';
import { HeaderComponent } from './header/header.component';

@NgModule({
  declarations: [
    AppComponent,
    StandbyComponent,
    ActiveFromOfficeComponent,
    PointAComponent,
    PointBComponent,
    HeaderComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
